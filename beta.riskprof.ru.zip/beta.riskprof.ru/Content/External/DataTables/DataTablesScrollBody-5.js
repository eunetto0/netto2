﻿/**
 * 
 * @param {string} tableName id объекта без #
 * @param {number} [minHeight] минимальная высота окна
 */
function ScrollBody(tableName, minHeight = 550) {
	let tableHeight = $(`#${tableName}`).outerHeight(true);

	let footer = $(`#${tableName}`).find('.dataTables_wrapper').outerHeight(true) - $(`#${tableName}`).find('.dataTables_scroll').outerHeight(true);

	let header = $(`#${tableName}`).find('.dataTables_scrollHead').outerHeight(true);

	let body = tableHeight - footer - header;

	let resultHeight = body;

	if (isNaN(minHeight) == false && minHeight > body)
		resultHeight = minHeight;

	$(`#${tableName}`).find('.dataTables_scrollBody').css({ 'height': resultHeight + 'px' });
}