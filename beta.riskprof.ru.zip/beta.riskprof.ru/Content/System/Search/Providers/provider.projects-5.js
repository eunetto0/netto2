﻿RiskProf.ProjectsSearchProvider = {
    ProjectsProvider: {
        Id: 1,
        SearchUrl: RiskProf.Settings.RiskServiceUrl + 'search/projects',
        SearchWord: '',
        CookieName: 'SearchWord_Projects',
        ShowAllResultsUrl: 'class="dropdown-item" onclick="window.EventRouter.publish(\'ShowAllSearchResults_Projects\', \'{searchWord}\')"',
        ShowAllResultsUrl_FromAnotherPage: 'class="dropdown-item" href="' + RiskProf.Settings.RiskServiceUrl + 'risk/list" onclick="setCookie(\'{cookieName}\', \'{searchWord}\', 1)"',
        ShowOneResultUrl: 'class="dropdown-item" href="{link}"',
        SearchMethod: function (text, searchList) {
            this.SearchWord = text;

            let data = {
                searchString: text
            }

            if (text.length > 1) {
                let textNumber = Number.parseInt(text.substring(1));

                if (text.indexOf('#') == 0 && Number.isInteger(textNumber)) {
                    data['projectId'] = textNumber;
                }
            }

            this.RequestMethod(data, searchList);
        },
        RequestMethod: function (data, targetList) {
            let localObject = this;

            $.ajax({
                "url": this.SearchUrl,
                "data": data,
                "type": "GET",
                "success": function (data) {
                    let result = localObject.ShowMethod(Array.from(data.Data), Array.from(data.Links), localObject.ShowAllResultsUrl.replace('{searchWord}', localObject.SearchWord));

                    addSearchResultToList(result, targetList, localObject.Id);

                    if (data.Error.length > 0)
                        alert(data.Error);
                },
                "error": function () {
                    showErrorSearch('Проекты', targetList);
                }
            });
        },
        ShowMethod: function (data, links, linkAllSearchResults) {
            var resultHtml = '<li><div style="padding: .25rem 1.5rem; font-weight: bold; text-align: center; background-color: #D3D3D3">Проекты</div></li>';

            if (data.length == 0)
                resultHtml += '<li><div style="padding: .25rem 1.5rem;">Результатов не найдено</div></li>';

            //Чтобы не отображать все результаты поиска, ограничиваем цикл добавления результатов в список до первых 5 проходов
            let maxSearchResultsLength = data.length > 5 ? data.length - 5 : 0;

            for (let i = 0; i < data.length - maxSearchResultsLength; i++) {
                //Шаблон ссылки на найденный объект может содержать не только тег href, но и class и id с нужной информацией
                resultHtml += '<li><a style="font-weight: bold;" class="dropdown-item" href="' + links[i] + '">' + data[i] + '</a></li>';
            }

            if (maxSearchResultsLength > 0) 
                resultHtml += '<li><a ' + linkAllSearchResults + '>Показать все результаты</a></li>';

            return resultHtml;
        }
    }
}