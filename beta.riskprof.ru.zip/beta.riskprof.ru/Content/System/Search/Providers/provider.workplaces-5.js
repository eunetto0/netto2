﻿RiskProf.WorkplacesSearchProvider = {
    WorkplacesProvider: {
        Id: 2,
        SearchUrl: RiskProf.Settings.RiskServiceUrl + 'search/workplaces',
        SearchWord: '',
        VersionId: '',
        RiskObjectTypeId: '',
        ShowAllResultsUrl: 'class="dropdown-item environmentDialog" data-riskobjecttypeid="{riskObjectTypeId}" data-searchword="{searchWord}"',
        SearchMethod: function (text, searchList) {
            this.SearchWord = text;

            let data = {
                searchString: text,
                versionId: this.VersionId
            }

            if (text.length > 1) {
                let textNumber = text.substring(1);

                if (text.indexOf('#') == 0) {
                    data['workplaceNumber'] = textNumber;
                }
            }

            this.RequestMethod(data, searchList);
        },
        RequestMethod: function (data, targetList) {
            let localObject = this;

            $.ajax({
                "url": this.SearchUrl,
                "data": data,
                "type": "GET",
                "success": function (data) {
                    let dataWorkplace = data.Data;
                    let dataOOR = data.TypesOOR;
                    let dataLinks = data.Links;

                    let keys = [ 'Рабочие места', 'Места выполнения работ', 'Выполняемые работы', 'Нештатные ситуации', 'Аварийные ситуации' ];
                    let result = '';

                    keys.forEach(function (item) {
                        if (dataOOR[item] != (null || undefined)) {
                            let ShowAllResultsUrl = localObject.ShowAllResultsUrl.replace('{riskObjectTypeId}', dataOOR[item]).replace('{searchWord}', localObject.SearchWord);

                            result += localObject.ShowMethod(Array.from(dataWorkplace[item]), Array.from(dataLinks[item]), item, ShowAllResultsUrl);
                        }
                    });

                    addSearchResultToList(result, targetList, localObject.Id);

                    if (data.Error.length > 0)
                        alert(data.Error);
                },
                "error": function () {
                    showErrorSearch('Рабочие места', targetList);
                }
            });
        },
        ShowMethod: function (data, links, title, linkAllSearchResults) {
            var resultHtml = '<li><div style="padding: .25rem 1.5rem; font-weight: bold; text-align: center; background-color: #D3D3D3">' + title + '</div></li>';

            if (data.length == 0)
                resultHtml += '<li><div style="padding: .25rem 1.5rem;">Результатов не найдено</div></li>';

            //Чтобы не отображать все результаты поиска, ограничиваем цикл добавления результатов в список до первых 5 проходов
            let maxSearchResultsLength = data.length > 5 ? data.length - 5 : 0;

            for (let i = 0; i < data.length - maxSearchResultsLength; i++) {
                //Шаблон ссылки на найденный объект может содержать не только тег href, но и class и id с нужной информацией
                resultHtml += '<li><a style="font-weight: bold;" class="dropdown-item workplaceEditRisk" id="' + links[i] + '" href="#">' + data[i] + '</a></li>';
            }

            if (maxSearchResultsLength > 0) 
                resultHtml += '<li><a ' + linkAllSearchResults + '>Показать все результаты</a></li>';

            return resultHtml;
        }
    }
}