﻿RiskProf.Search = function () {
    this._timerId = null;
    this._searchWord = '';
    this._searchWordEnvironment = '';
    this._providerOrder = [1, 2];
    this._providersResults = { };
}

RiskProf.Search.prototype.Find = function (providers, text, searchList, isEnterPressed) {
	if (providers == (null || undefined))
        return;

    //Обнуляем таймер отправки запроса на поиск, даже если он не истек
    if (this._timerId != (null || undefined))
        clearTimeout(this._timerId);

    //Если регистрируется провайдер "Поиск по рабочим местам", то в провайдере "Поиск по проектам" меняем шаблон ссылки, ведущей на странцу "Показать все результаты"
    if (providers['WorkplacesProvider'] != (null || undefined))
        providers.ProjectsProvider.ShowAllResultsUrl = providers.ProjectsProvider.ShowAllResultsUrl_FromAnotherPage.replace('{cookieName}', providers.ProjectsProvider.CookieName);

    let providersArray = Object.entries(providers);

    //Если пользовать в поисковой строке нажал Enter, то отправляем запрос на поиск без задержек
    if (isEnterPressed)
        runSearch(providersArray, text, searchList);
    else
        this._timerId = setTimeout(runSearch, 2000, providersArray, text, searchList);
}

RiskProf.Search.Instance = new RiskProf.Search();

function runSearch(providers, searchWord, searchList) {
    RiskProf.Search.Instance._searchWord = searchWord;

    searchList.html('');
    searchList.css('display', 'block');

    RiskProf.Search.Instance._providersResults = { };

    for (let i = 0; i < providers.length; i++) {
        providers[i][1].SearchMethod(searchWord, searchList);
    }
}

function addSearchResultToList(result, targetList, providerId) {
    let providersResults = RiskProf.Search.Instance._providersResults;
    let providersOrder = RiskProf.Search.Instance._providerOrder;

    providersResults[providerId] = result;

    let mainResult = '';

    for (let i = 0; i < providersOrder.length; i++) {
        if (providersResults[providersOrder[i]] != (null || undefined)) {
            mainResult += providersResults[providersOrder[i]];
        }
    }

    targetList.html(mainResult);
}

function showErrorSearch(title, targetList) {
    var resultHtml = '<li><a class="dropdown-item" style="font-weight: bold; text-align: center; background-color: #D3D3D3">' + title + '</a></li>';

    resultHtml += '<li><div style="padding: .25rem 1.5rem;">При выполнении поиска возникла неизвестная ошибка</div></li>';

    targetList.append(resultHtml);
}