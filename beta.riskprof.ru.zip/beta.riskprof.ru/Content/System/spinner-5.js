﻿IsSpinnerInserted = false
function SpinnerFadeIn(text, time) {
	
	if (!IsSpinnerInserted) {
		$("<div class='spinner text-center text-danger'><div style='margin-top: 40vh;'><div><i class='fa fa-spinner fa-pulse fa-5x fa-fw'></i></div><strong class='spinner_text'>Загрузка...</strong></div ></div >").appendTo($("body"));
		console.log("inserted");
		IsSpinnerInserted = true;
	}
	
	if (text === undefined || text === "") {
		$('.spinner_text').html("");
	}
	else $('.spinner_text').html(text);
	if (time === undefined || time === null) {
		$('.spinner').fadeIn();
	}
	else $('.spinner').fadeIn(time);
}

function SpinnerFadeOut(time) {
	if (time === undefined || time === null) {
		$('.spinner').fadeOut('fast');
	}
	else $('.spinner').fadeOut(time);
}