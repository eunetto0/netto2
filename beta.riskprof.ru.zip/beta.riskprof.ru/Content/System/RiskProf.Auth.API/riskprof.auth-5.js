﻿RiskProf.AuthClient = function (authServiceUrl) {
    this._userTokenCookieName = 'RiskProf_UserToken';
    this._getNavMenu = authServiceUrl + 'nav/menu';
    this._getHeader = authServiceUrl + 'nav/header';
    this._selectCabinetTreeHead = authServiceUrl + 'cabinet/cabinetTree/head';
    this._postSwitchCabinetUrl = authServiceUrl + 'user/switchCabinet';

    this._refreshUserAuth = '/user/refreshuserauth';
    this._setCookies = 'setAuthCookie';
    this._sessionCabinetId = '';
}


RiskProf.AuthClient.prototype.InitSessionCabinetId = function (sessionCabinetId) {
    this._sessionCabinetId = sessionCabinetId;
}

RiskProf.AuthClient.prototype.InitUserToken = function (successHandler) {
    this.UserToken = Cookies.get(this._userTokenCookieName);
    if (!RiskProf.Lib.IsEmptyOrNull(successHandler)) successHandler();
}

RiskProf.AuthClient.prototype.ClearUserToken = function () {
    Cookies.remove(this._userTokenCookieName);
    window.location.reload();
    return;
}

RiskProf.AuthClient.prototype.GetUserToken = function () {
    if (RiskProf.Lib.IsEmptyOrNull(this.UserToken)) {
        this.UserToken = Cookies.get(RiskProf.AuthClient.Instance._userTokenKey);
    }
    return this.UserToken;
}

RiskProf.AuthClient.prototype.GetNavMenu = function () {
    if (RiskProf.Lib.IsEmptyOrNull(this.UserToken)) return;

    $.get(this._getNavMenu, {
        userToken: this.UserToken
    }, function (response) {
        $("#sidebar").html(response);
    });
};

RiskProf.AuthClient.prototype.GetHeader = function (successHandler = null) {
    if (RiskProf.Lib.IsEmptyOrNull(this.UserToken)) return;

    $.get(this._getHeader, {
        userToken: this.UserToken
    }, function (response) {
        $("#nav_panel").html(response);
        if (successHandler != (null && undefined) && typeof successHandler === 'function') {
            successHandler(response);
        }
    });
};

RiskProf.AuthClient.prototype.FillSelectCabinetTreeHead = function (selectElement) {
    if (!this.UserToken) {
        this.InitUserToken();

    }
    $.get(this._selectCabinetTreeHead, {
        userToken: this.UserToken
    }, function (response) {
        console.log(selectElement);

        $.each(response.items, function (index, item) {
            if (item.IsAccess == false) {
                $(selectElement).append('<option value="' + item.Id + '" disabled >' + item.FormatOrganizationName + '</option>');
            } else
                if (item.Id == response.currentCabinetId) {
                    $(selectElement).append('<option value="' + item.Id + '" selected>' + item.FormatOrganizationName + '</option>');

                } else {
                    $(selectElement).append('<option value="' + item.Id + '">' + item.FormatOrganizationName + '</option>');
                }
        });
        if (response.items.length > 0) {
            $(selectElement).show();
            $(selectElement + '_label').show();
        }
        $(selectElement).change(function () {
            let cabinetId = $(this).children(":selected").val();
            let url = '/risk/workplace/redirect?cabinetId=' + cabinetId;
            RiskProf.AuthClient.Instance.SwitchCabinet(cabinetId, url);
        });
    });

}

RiskProf.AuthClient.prototype.Resize = function () {
    setTimeout(function () {
        var nav_panel = $('#nav_panel').outerHeight();
        var nav_info = $('#nav_info').outerHeight();
        var content_core = $('#head_content').outerHeight() - $('#module-menu').outerHeight();
        $("#nav_info").css({ 'margin-top': nav_panel });
        $("#contentBody").css({ 'margin-top': nav_panel + nav_info });
        $("#contentBody").css({ 'min-height': document.documentElement.clientHeight - nav_panel - nav_info });
    }, 50);
    if (document.documentElement.clientWidth <= 767) {
        $(".desktop-module-menu").css({ 'display': 'none' });
        $(".mobile-module-menu").css({ 'display': 'block' });
        $("#sidebar").addClass("sidebar-mobile-active");
        $("#nav_panel_pk").css({ 'display': 'none' });
        $("#nav_panel_mobile").css({ 'display': 'flex' });
        $("#sidebar").css({ 'display': 'none' });
        $("#head_content").css({ 'width': '100%' });
        $("#sidebar").removeClass("active");
        $("#head_content").removeClass("active");
        $("#sidebarbt_mobile").removeClass("active");
    } else {
        $("#sidebar").removeClass("sidebar-mobile-active");
        $("#nav_panel_pk").css({ 'display': 'flex' });
        $("#nav_panel_mobile").css({ 'display': 'none' });
        $("#sidebar").css({ 'display': 'block' });
        $(".desktop-module-menu").css({ 'width': 'calc(100% - ' + $('#sidebar').outerWidth() + 'px)' });
        $(".mobile-module-menu").css({ 'display': 'none' });
        $(".desktop-module-menu").css({ 'display': 'block' });
        setTimeout(function () {
            var sidebar = $('#sidebar').width();
            $("#head_content").css({ 'width': 'calc(100% - ' + sidebar + 'px)' });
        }, 100);
    }
    setTimeout(function () {
        $("#content-core").css({ 'margin-top': 'calc(' + $('#module-menu').outerHeight() + 'px)' });
        $("#content-core").css({ 'width': '100%' });
    }, 100);
};

RiskProf.AuthClient.prototype.CheckCabinet = function (cabinetId) {
    console.log('sessionCabinetID:' + this._sessionCabinetId);
    if (this._sessionCabinetId != cabinetId) {
        $.post(this._refreshUserAuth, {
        }, function (response) {
            location.reload();
            console.log('sessionCabinetID:' + this._sessionCabinetId);
        });
    }
}

RiskProf.AuthClient.prototype.RefreshUserAuth = function () {
    $.post(this._refreshUserAuth, {
    }, function (response) {
        location.reload();
    });
}

RiskProf.AuthClient.prototype.SwitchCabinet = function (cabinetId, url) {
    if (RiskProf.Lib.IsEmptyOrNull(this.UserToken)) return;
    $.ajax({
        type: "POST",
        url: this._postSwitchCabinetUrl,
        data: { userToken: this.UserToken, cabinetId: cabinetId },
        dataType: "json",
        success: function (data) {
            if (data.state == 0) {
                setCookie("RiskProf_UserToken", data.userToken, 365);
                console.log(url);
                if (url) {
                    window.location.href = url;
                } else {
                    window.location.reload();
                }
            } else {

                alert("Возникла ошибка при смене кабинета")
            }
        }
    });
}

RiskProf.AuthClient.Instance = new RiskProf.AuthClient(RiskProf.Settings.authUrl);

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}