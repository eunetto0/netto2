﻿RiskProf.Bitrix24 = function () {

}

RiskProf.Bitrix24.prototype.Init = function () {
    var chatButton=""

    //$("<div id='b24-widget' style='position: fixed; z-index: 99999; right: 50px; bottom: 50px; cursor: pointer;'><img src='/Content/System/Images/LiveSupportChat.png'/></div>").appendTo($("body"));
    //console.log("button inserted");
    let widgetButton = document.getElementById("b24-widget");
    if (widgetButton != null)
        widgetButton.remove();

    (function (w, d, u) {
        var s = d.createElement('script'); s.async = true; s.src = u + '?' + (Date.now() / 60000 | 0);
        var h = d.getElementsByTagName('script')[0]; h.parentNode.insertBefore(s, h);
    })(window, document, 'https://cdn-ru.bitrix24.ru/b5811463/crm/site_button/loader_2_n28oe6.js');
};

RiskProf.Bitrix24.prototype.LiveSupportChat = function () {
    $('div.b24-widget-button-inner-container').click();
    $('div.bx-livechat-wrapper').draggable({ handle: '.bx-livechat-copyright, .bx-livechat-body' });
};

RiskProf.Bitrix24.Instance = new RiskProf.Bitrix24();
