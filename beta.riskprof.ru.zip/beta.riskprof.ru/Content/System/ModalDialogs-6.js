﻿_modal_zIndex_max = 1055;

function ModalDialogV2_show(html, customModalDialogClasses = '', customModalDialogStyles = '', customModalContentClasses = '', customModalContentStyle = '') {
	var guid = uuidv4();
	var content = $("<div/>").addClass('modal-content').addClass(customModalContentClasses).attr('style', `max-height: calc(100vh - 45px); ${customModalContentStyle}`);
	var dialog = $("<div/>").addClass('modal-dialog modal-lg').addClass(customModalDialogClasses).attr('style', `max-height: calc(100vh - 45px); ${customModalDialogStyles}`).append(content);
	var newBackdrop = $("<div/>").addClass("modal-backdrop show").attr("target-windowId", guid).attr('style', `z-index: ${++_modal_zIndex_max} !important;`);
	var newElem = $("<div/>").addClass('modalWindow modal bd-example-modal-lg')
		.attr('id', guid)
		.attr('tabindex', '-1')
		.attr('role', 'dialog')
		.attr("data-backdrop", false)
		.attr("data-keyboard", "false")
		.attr("aria-hidden", "true")
		.attr('style', `z-index:${++_modal_zIndex_max}; height: 100vh`).append(dialog);
	$("body").append(newElem);
	$("body").append(newBackdrop);
	newElem.off('click', '.close,.modalButtonClose');
	newElem.on('click', '.close,.modalButtonClose', function () {
		var $thisObject = $(this);
		console.log($thisObject);
		ModalDialog_hide($thisObject);
	});
	$('#' + guid + ' .modal-content').html(html);
	$('#' + guid + ' .modal-dialog').removeClass('fadeOut').addClass('fadeIn');
	//$('#' + guid).modal('show');
	$('#' + guid).css('display', 'block');

	//$('#' + guid).on('keyup', function (e) {
    //    if (e.which === 27) {
    //        ModalDialog_hide($thisObject);
    //    }
    //});
	return guid;
}

IsModalInserted = false
function ModalDialogV3_showIframe(url, height = '100%', width = '95%', relocateCloseButton = true) {
	if (width == null) {
        width = '95%';
    }
	var content =
		'<style>'
		+ '		.modal-dialog-modified3 { min-width: 0px !important; width: ' + width + ' !important;}'
		+ '		.content-modified {padding: 0px !important;}';
	//if (relocateCloseButton) {
 //       content +=
 //           '	.modal-modified-close { z-index:10; left: auto !important; right: 25px !important; top: 15px !important; border:none !important; background-color:transparent !important; }' +
 //           '	.fa-times { font-size: 30px; color: black; }';
 //   }
    content += '</style>'
		+ '<iframe id="iframeLoad" src="/Content/System/spiner.html" width="100%" height="100%" allowfullscreen = "true"  style="border:0;" frameBorder="0"></iframe>'
		+ '<iframe id="iframeDialog" src="' + url + '" width="100%" height="100%" allowfullscreen = "true"  style="display:none; border:0;" frameBorder="0"></iframe>'
	+ '<script>'
	+ '		$("#iframeDialog").load(function () { '
	+ '			$("#iframeLoad").remove();'
	+ '			$("#iframeDialog").show();'
	+ '		});'
	+ '</script>';

	// let $dialogBody =
	window.ModalDialogV3_show(content);
	// $dialogBody.find('.modal-modified-close i').addClass('fa-3');
}

function ModalDialogV3_show(response, customDialogStyle = '') {

	//if (!IsModalInserted) {
	//	$("<div class='modal fade bd-example-modal-lg' id='modalDialogV3' tabindex='-1' role='dialog' aria-labelledby='myLargeModalLabel' aria-hidden='true' data-backdrop='static' data-keyboard='false' style='z-index:1055; height: 100vh;'><div class= 'modal-dialog modal-lg' style = 'height: calc(100vh - 45px);' ><div class='modal-content' style='height: calc(100vh - 45px);'></div></div></div>").appendTo($("body"));
	//	console.log("inserted");
	//	IsModalInserted = true;
	//}

	var styleBlock = '<style> body {overflow: hidden;} <style>';
	var guid = uuidv4();
	var close = $("<div/>").addClass("modal-modified-close cancel").attr("data-id", guid).append($("<i/>").addClass("fa fa-times"));
	var content = $("<div/>").addClass("content-modified");
	var dialog = $("<div/>").addClass("modal-dialog-modified3 animated").attr('style', customDialogStyle).append(close).append(content);
	//var newBackdrop = $("<div/>").addClass("modal-backdrop show").removeClass('fadeOut').addClass('fadeIn').attr("target-windowId", guid).attr('style', `z-index: ${++_modal_zIndex_max} !important;`);
	var newElem = $("<div/>").addClass("modalWindow modal-modified").attr("id", guid).attr("role", "dialog").attr("data-backdrop", false).css('position', 'fixed').css('z-index', ++_modal_zIndex_max).append(styleBlock).append(dialog);
	let $body = $("body").append(newElem);
	//$("body").append(newBackdrop);

	$('#' + guid + ' .content-modified').html(response);
	$('#' + guid + ' .keep').attr("data-id", guid);
	$('#' + guid + ' .cancel').attr("data-id", guid);
	$('#' + guid + ' .modal-dialog-modified3').removeClass('fadeOutRight').addClass('fadeInRight');
	//$('#' + guid).modal('show');
	$('#' + guid).css('display', 'block');
	return guid;
}

/**
 * @param {any} settings - параметры BoostrapDialogShow, кроме onshow и onhide
 * @param {any} onshowFunction - функция для параметра onshow
 * @param {any} onhideFunction - функция для параметра onhide
 */
function ModalDialogBoostrap_show(settings, onshowFunction, onhideFunction) {
	settings.closable = false;

	settings.onshow = function (dialog) {
		dialog.getModal().on('click', '.close', function () {
			dialog.close();
		});

		if (onshowFunction != (null || undefined) && (typeof onshowFunction === 'function'))
			onshowFunction(dialog);
	};

	settings.onhide = function (dialog) {
		if (onhideFunction != (null || undefined) && (typeof onhideFunction === 'function'))
			onhideFunction(dialog);

		_modal_zIndex_max -= 1;
	};

	BootstrapDialog.Z_INDEX_BACKDROP = ++_modal_zIndex_max;
	BootstrapDialog.Z_INDEX_MODAL = ++_modal_zIndex_max;

	BootstrapDialog.show(settings);
}

function ModalDialog_hide(innerObject) {
	var object = innerObject.closest(".modalWindow");

	if (object != (null && undefined && innerObject)) {

		$(object).find('.modal-dialog').removeClass('fadeIn').addClass('fadeOut');
		$(object).find('.modal-dialog-modified3').removeClass('fadeInRight').addClass('fadeOutRight');

		var id = $(object).attr('id');

		var backdrop = $('.modal-backdrop[target-windowId="' + id + '"]');
		$(backdrop).removeClass('fadeIn').addClass('fadeOut');

		if ($(object).find('.modal-dialog-modified3').length > 0) {
			setTimeout(function () {
				$(backdrop).remove();
				$(object).modal('hide');
				$(object).remove();
				$(window).resize();
			}, 500);
		}
		else {
			$(backdrop).remove();
			$(object).modal('hide');
			$(object).remove();
			$(window).resize();
		}

		_modal_zIndex_max -= 1;
	}
}

/**
 * Не использовать, неактуально (но Auth считает иначе)
 * 
 * @param {any} id
 */
function ModalDialogV3_hide(id) {
	$('#' + id + ' .modal-dialog-modified3').removeClass('fadeInRight').addClass('fadeOutRight');
	var backdrop = $('.modal-backdrop[target-windowId="' + id + '"]');
	$(backdrop).removeClass('fadeIn').addClass('fadeOut');
	setTimeout(function () {
		$(backdrop).remove();
		//$('#' + id).modal('hide');
		$('#' + id).remove();
	}, 500);
}
function ModalDialogV2_hide(id) {
	$('#' + id + ' .modal-dialog-modified3').removeClass('fadeInRight').addClass('fadeOutRight');
	var backdrop = $('.modal-backdrop[target-windowId="' + id + '"]');
	$(backdrop).removeClass('fadeIn').addClass('fadeOut');
	setTimeout(function () {
		$(backdrop).remove();
		//$('#' + id).modal('hide');
		$('#' + id).remove();
	}, 500);
}

function uuidv4() {
	return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
		(c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
	);
}

$(document).on('click', '.cancel', function (e) {
	var thisObject = this;
	e.stopPropagation();
	ModalDialog_hide(thisObject);
});

//// Во внутренней разметке выпадающей шторки на кнопке "Отмена" нужно установить класс "cancel"
//// кнопке "Сохранить" нужно установить класс "keep", так можно будет получить id = $(this).attr("data-id") для закрытия нужной шторки
//// для эффекта плавного появления и скрытия нужно подключить animate.css