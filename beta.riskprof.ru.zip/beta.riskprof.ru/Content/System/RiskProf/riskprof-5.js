﻿if (typeof RiskProf == 'undefined') RiskProf = {}
//if (typeof RiskProf.Lib == undefined)
	RiskProf.Lib = {}

RiskProf.Lib.IsEmptyOrNull = function (value) {
	return (value == null || value == '' || value == 'undefined');
}


RiskProf.Lib.IsTrue = function (value) {
	if (typeof (value) === 'string') {
		value = value.trim().toLowerCase();
	}
	switch (value) {
		case true:
		case "true":
		case 1:
		case "1":
		case "on":
		case "yes":
			return true;
		default:
			return false;
	}
}
//RiskProf.Lib.dhtmlLoadScript = function (url, callback) {
//	var existsElement = document.getElementsByTagName("head")[0].querySelector('script[src="' + url + '"]');
//	if (existsElement != (null && undefined)) {
//		if (existsElement.readyState == "loaded" ||
//			existsElement.readyState == "complete") {
//			console.log('script "' + url + '" is already loaded');
//			callback();
//		}
//		else {
//			console.log('script "' + url + '" already loading');
//			existsElement.onreadystatechange = (function (pre) {
//				return function () {
//					pre && pre.apply(this, arguments);
//					if (existsElement.readyState == "loaded" ||
//						existsElement.readyState == "complete") {
//						existsElement.onreadystatechange = null;
//						callback();
//					}
//				}
//			})(existsElement.onreadystatechange);
//		}
//	}
//	else {
//		console.log('script "' + url + '" is new loading');
//		var script = document.createElement("script")
//		script.type = "text/javascript";

//		if (script.readyState) {  //IE
//			existsElement.onreadystatechange = (function (pre) {
//				return function () {
//					pre && pre.apply(this, arguments);
//					if (existsElement.readyState == "loaded" ||
//						existsElement.readyState == "complete") {
//						existsElement.onreadystatechange = null;
//						callback();
//					}
//				}
//			})(existsElement.onreadystatechange);
//		} else {  //Others
//			script.onload = (function (pre) {
//				return function () {
//					pre && pre.apply(this, arguments);
//					callback();
//				}
//			})(script.onload);
//		}
//		script.src = url;
//		document.getElementsByTagName("head")[0].appendChild(script);
//	}
//}

RiskProf.Lib.dhtmlLoadScript = function (url, callback) {
	var script = document.createElement("script")
	script.type = "text/javascript";

	if (script.readyState) {  //IE
		script.onreadystatechange = function () {
			if (script.readyState == "loaded" ||
				script.readyState == "complete") {
				script.onreadystatechange = null;
				callback();
			}
		};
	} else {  //Others
		script.onload = function () {
			callback();
		};
	}

	script.src = url;
	document.getElementsByTagName("head")[0].appendChild(script);
}

RiskProf.Lib.dhtmlLoadCSS = function(url) {
	var existsElement = document.getElementsByTagName("head")[0].querySelector('link[type="text/css"][rel="stylesheet"][href="' + url + '"]');
	if (existsElement != (null && undefined)) {
		console.log('stylesheet "' + url + '" already added');
	}
	else {
		var link = document.createElement("link");
		link.setAttribute("rel", "stylesheet");
		link.setAttribute("type", "text/css");
		link.setAttribute("href", url);
		document.getElementsByTagName("head")[0].appendChild(link)
	}
}

RiskProf.Lib.InsertParamUrl = function(key, value) {
	key = escape(key); value = escape(value);
	var baseUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
	if (history.pushState) {
		var kvp = document.location.search.substr(1).split('&');
		if (kvp == '')
		{
			history.pushState(null, null, baseUrl + '?' + key + '=' + value);
		}
		else {
			kvps = [];
			var i = kvp.length; var x; while (i--) {
				x = kvp[i].split('=');
				if (x[0] == key) {
					x[1] = value;
					kvp[i] = x.join('=');
					if(x[1]) kvps.push(kvp[i]);
					break;
				} else {
					if (x[1]) kvps.push(kvp[i]);
                }
			}

			if (i < 0) {
				kvp[kvp.length] = [key, value].join('=');

				if (value) kvps.push([key, value].join('='))
			}

			history.pushState(null, null, baseUrl + '?' + kvps.join('&'));
		}
	} else {
		console.warn('History API не поддерживается');
	}
}

$.extend({
	getUrlVars: function () {
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for (var i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	},
	getUrlVar: function (name) {
		return $.getUrlVars()[name];
	}
});