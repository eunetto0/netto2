﻿if (!RiskProf) RiskProf = {}

RiskProf.DependencyResolved = function () {
    this._items = new Map();
}

RiskProf.DependencyResolved.prototype.Registration = function (name, instance) {
    this._items.set(name,instance);
}

RiskProf.DependencyResolved.prototype.Resolved = function (name) {
    //console.log(this._items);
    //console.log(name, this._items.has(name), this._items.get(name));

    this._items.forEach(function (value, key) {
        //console.log('key = ' + key + ', value = ' + value);
    });

    return this._items.get(name);
}


RiskProf.DependencyResolvedManager = new RiskProf.DependencyResolved();