﻿if (typeof RiskProf === 'undefined') {
    RiskProf = {}
}
RiskProf.Settings = {
    authUrl: 'https://id.riskprof.ru/',
    Application: 'PSOT',
    GroupsServiceUrl: 'http://localhost:57200/',
    EventsServiceUrl: 'http://localhost:63414/',
    FeedsServiceUrl: 'http://localhost:65240/',
    CommentsServiceUrl: 'https://comment-ms.riskprof.ru',
    ActionsServiceUrl: 'https://action-ms.riskprof.ru',
    AccessTreeServiceUrl: 'https://access-ms.riskprof.ru',
    /*AccessTreeServiceUrl: 'http://localhost:60022/',*/
    FilesServiceUrl:'https://files-ms.riskprof.ru',    
    ProfessionsUrl: 'https://kb-prof.riskprof.ru/',
    HazardUrl: 'https://kb-hazard.riskprof.ru/',
    //InvoiceWebAppUrl: 'http://riskprof.ru/',
    InvoiceWebAppUrl: 'http://localhost:9612/',
    RiskServiceUrl: 'https://beta.riskprof.ru/',
    StaffUrl: 'https://staff2.riskprof.ru/',
    EduServiceUrl: "https://demo.edu.smarta.life/",
    SoutServiceUrl: "https://sout.riskprof.ru/",
	IdentUrl: 'https://sout-ident.riskprof.ru/',
    FactorDescriptionUrl: 'https://kb-factor.riskprof.ru/',
    AgentDescriptionUrl: 'https://chemistry-kb.riskprof.ru/',
	StaffUtUrl: 'http://ut.staff.riskprof.ru/',
}