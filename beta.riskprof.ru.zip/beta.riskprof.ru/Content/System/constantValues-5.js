﻿const QuestionListSelectionMode = {
    No: 0,
    Single: 1,
    Multiple: 2
}
