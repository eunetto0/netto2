﻿if (!RiskProf) RiskProf = {};

RiskProf.IdentClient = function (identServiceUrl) {
	this._getFactorsUrl = identServiceUrl + 'factor/get';
	this._getKutsUrl = identServiceUrl + 'kut/get';
};

RiskProf.IdentClient.prototype.GetFactorsIdent = function (model, successHandler) {
	this.UserToken = Cookies.get('RiskProf_UserToken');
	$.ajax({
		headers: { 'RiskProf_UserToken': this.UserToken },
		type: "Post",
		url: RiskProf.IdentClient.Instance._getFactorsUrl,
		data: model,
		success: function (data) {
			successHandler(data);
		}
	});
};
RiskProf.IdentClient.prototype.GetKutsIdent = function (model, successHandler) {
	this.UserToken = Cookies.get('RiskProf_UserToken');
	$.ajax({
		headers: { 'RiskProf_UserToken': this.UserToken },
		type: "Post",
		url: RiskProf.IdentClient.Instance._getKutsUrl,
		data: model,
		success: function (data) {
			successHandler(data);
		}
	});
};
RiskProf.IdentClient.Instance = new RiskProf.IdentClient(RiskProf.Settings.IdentUrl);

RiskProf.FactorsClient = function (factorDescriptionUrl) {
	this._getFactorDescriptionUrl = factorDescriptionUrl + 'factor/get';
}
RiskProf.FactorsClient.prototype.GetFactorDescriptionUrl = function (model, successHandler) {
	this.UserToken = Cookies.get('RiskProf_UserToken');
	$.ajax({
		headers: { 'RiskProf_UserToken': this.UserToken },
		type: "GET",
		url: RiskProf.FactorsClient.Instance._getFactorDescriptionUrl,
		data: model,
		success: function (data) {
			successHandler(data);
		}
	});
}
RiskProf.FactorsClient.Instance = new RiskProf.FactorsClient(RiskProf.Settings.FactorDescriptionUrl);

RiskProf.AgentsClient = function (agentDescriptionUrl) {
	this._getChemistryAgentDescriptionUrl = agentDescriptionUrl + 'chemistry/get';
}
RiskProf.AgentsClient.prototype.GetChemistryAgentDescriptionUrl = function (model, successHandler) {
	this.UserToken = Cookies.get('RiskProf_UserToken');
	$.ajax({
		headers: { 'RiskProf_UserToken': this.UserToken },
		type: "GET",
		url: RiskProf.AgentsClient.Instance._getChemistryAgentDescriptionUrl,
		data: model,
		success: function (data) {
			successHandler(data);
		}
	});
}
RiskProf.AgentsClient.Instance = new RiskProf.AgentsClient(RiskProf.Settings.AgentDescriptionUrl);