﻿Sm = {};
Sm.EventRouter = function () {
    this.events = {};
}
Sm.EventRouter.prototype.subscribe = function (eventName, callback, context) {
    if (!this.events[eventName]) {
        this.events[eventName] = [];
    }
    this.events[eventName].push({ func: callback, ctx: context });
};
Sm.EventRouter.prototype.clear = function (eventName) {
    if (!this.events[eventName]) {
        this.events[eventName] = [];
    }
};
Sm.EventRouter.prototype.override = function (eventName, callback, context) {
    this.events[eventName] = [];
    this.events[eventName].push({ func: callback, ctx: context });
};

Sm.EventRouter.prototype.publish = function (eventName, parameters) {
    if (!this.events[eventName]) {
        console.log('Event published with no lsiteners: ' + eventName);
        return;
    }
    this.events[eventName].forEach(function (el) {
        el.func.apply(el.ctx, [parameters || {}]);
    });
};
Sm.EventRouter.prototype.unsubscribe = function (eventName, callback) {
    if (!this.events[eventName]) {
        return;
    }
    this.events[eventName] = this.events[eventName].filter(function (el) {
        return el !== callback;
    });
};
window.EventRouter = new Sm.EventRouter();

var notifySettingsSuccess = {
    delay: 2000,
    timer: 1000,
    z_index: 9999,
    type: 'success',
    animate: {
        enter: 'animated fadeInDown',  //'animated lightSpeedIn',//enter: 'animated fadeInRight',
        exit: 'animated fadeOutRight'  //'animated lightSpeedOut'//exit: 'animated fadeOutRight'
    },
    newest_on_top: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 30
};
var notifySettingsWarning = {
    delay: 2000,
    timer: 1000,
    z_index: 9999,
    type: 'warning',
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutRight'
    },
    newest_on_top: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 30
};
var notifySettingsDanger = {
    delay: 2000,
    timer: 1000,
    z_index: 9999,
    type: 'danger',
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutRight'
    },
    newest_on_top: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 30
};

var notifySettingsMessage = {
    delay: 100000,
    z_index: 9999,
    type: 'success',
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutRight'
    },
    newest_on_top: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 30,

};
var notifyWarrgingLongMessage = {
    delay: 5000,
    z_index: 9999,
    type: 'warning',
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutRight'
    },
    newest_on_top: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 10,

};