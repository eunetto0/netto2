﻿const _q1ViewUrl = RiskProf.Settings.RiskServiceUrl + '/q1/question/data';
const _q2ViewUrl = RiskProf.Settings.RiskServiceUrl + '/q2/question/data';
const _createWorkplaceViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/reference/RiskWorkplaceNew/Create';
const _createRiskObjectViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/Create';
const _riskEditorViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/workplace/riskeditor';
const _copyRiskObjectUrl = RiskProf.Settings.RiskServiceUrl + '/risk/CopyRiskObject';
const _copyRiskObjectGetInfoUrl = RiskProf.Settings.RiskServiceUrl + '/risk/GetCopyInformation';
const _checkWorkplaceReferencesUrl = RiskProf.Settings.RiskServiceUrl + '/risk/workplace/checkReferences';
const _deleteWorkplaceUrl = RiskProf.Settings.RiskServiceUrl + '/risk/workplace/delete';
const _requirementObjectLinkViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/reference/requirement/objectLink/view';
const _hazardSourcesKbSearchUrl = RiskProf.Settings.RiskServiceUrl + '/risk/hazardSource/globalKB/select';
const _hazardSourcesKbCopyToWorkplaceUrl = RiskProf.Settings.RiskServiceUrl + '/risk/hazardSource/globalKB/copyToWorkplace';
const _riskObjectKbSearchUrl = RiskProf.Settings.RiskServiceUrl + '/risk/workEnvironment/searchRiskObjects/Ajax';
const _riskObjectKbCopyToWorkplacesUrl = RiskProf.Settings.RiskServiceUrl + '/version/RiskObjectsMassEditAjax';
const _riskObjectKbCopyFromTemplateUrl = RiskProf.Settings.RiskServiceUrl + '/Version/CopyRiskObjectsFromTemplates';
const _workEnvironmentViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/workEnvironment/view';
const _reportSettingsViewUrl = RiskProf.Settings.RiskServiceUrl + '/risk/version/reportSettings';
const _reportUpdateUrl = RiskProf.Settings.RiskServiceUrl + '/report/forms/update';
const _deleteHazardSourceItemsUrl = RiskProf.Settings.RiskServiceUrl + '/risk/reference/RiskHazardSource/DeleteEntityItems';

function Q1PlayerModalDialog(versionId, workplaceId) {
    var guid = null;

    var data = {
        versionId: versionId,
        workplaceId: workplaceId,
    };
    SpinnerFadeIn();
    $.get(_q1ViewUrl, data, function (response) {
        guid = ModalDialogV2_show(response, null, 'height:80vh; max-width: 40vw;', null, 'height:100% !important;');
    })
        .fail(function () {
            alert("Нет доступных опросов");
        })
        .always(function () {
            SpinnerFadeOut();
            return guid;
        });
}

function Q2PlayerModalDialog(versionId, workplaceId, targetWorkTypeItemId) {
    var guid = null;

    var data = {
        versionId: versionId,
        workplaceId: workplaceId,
        targetId: targetWorkTypeItemId,
    };
    SpinnerFadeIn();
    $.get(_q2ViewUrl, data, function (response) {
        guid = ModalDialogV2_show(response, null, 'height:80vh; max-width: 40vw;', null, 'height:100% !important;');
    })
        .fail(function () {
            alert("Нет доступных опросов");
        })
        .always(function () {
            SpinnerFadeOut();
            return guid;
        });
}

function CreateRiskObjectModalDialog(versionId, riskObjectTypeId, riskObjectTypeShortTitle, unitGuid) {
    var guid = null;
    var data = {
        versionId: versionId,
        riskObjectTypeId: riskObjectTypeId,
        riskObjectTypeShortTitle: riskObjectTypeShortTitle,
        unitId: unitGuid
    };

    SpinnerFadeIn();

    $.get(_createRiskObjectViewUrl, data, function (response) {
        guid = ModalDialogV2_show(response, null, 'max-height:98vh; height:98vh; margin-top:1vh; margin-bottom:1vh; max-width: 60vw;', null, 'max-height:98vh; height:100% !important;');
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert(jqXHR.responseText);
        })
        .always(function () {
            SpinnerFadeOut();
            return guid;
        });

    return false;
}

function CreateWorkTypeModalDialog(versionId, workplaceId) {
    var guid = null;
    var data = {
        versionId: versionId,
        workplaceId: workplaceId,
        isWorkTypeCreating: true
    };

    SpinnerFadeIn();

    $.get(_createRiskObjectViewUrl, data, function (response) {
        guid = ModalDialogV2_show(response, null, 'max-height:98vh; height:98vh; margin-top:1vh; margin-bottom:1vh; max-width: 60vw;', null, 'max-height:98vh; height:100% !important;');
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert(jqXHR.responseText);
        })
        .always(function () {
            SpinnerFadeOut();
            return guid;
        });

    return false;
}

function CreateWorkplaceModalDialog(versionId, unitGuid, riskObjectTypeGuid) {
    var data = {
        'workplaceId': '00000000-0000-0000-0000-000000000000',
        'versionId': versionId,
        'unitGuid': unitGuid,
        'riskObjectTypeGuid': riskObjectTypeGuid,
    };
    var url = _createWorkplaceViewUrl;
    SpinnerFadeIn();
    $.get(url, data, function (response) {
        ModalDialogV2_show(response);
    })
        .fail(function () { alert("error"); })
        .always(function () {
            SpinnerFadeOut();
        });
}

/**
 * 
 * @param {any} versionId
 * @param {any} workplaceId
 * @param {Function} successHandler
 */
function OpenWorkplaceEditorById(versionId, workplaceId, successHandler = null) {
    var data = {
        versionId: versionId,
        workplaceId: workplaceId,
        isReadOnly: false
    };
    SpinnerFadeIn();
    $.get(_riskEditorViewUrl, data, function (response) {
        var modalGuid = ModalDialogV3_show(response);
        $(`#${modalGuid}`).on('click', ' .cancel', function () {
            setTimeout(function () { $(window).resize(); }, 500);
        });
        if (successHandler != (null && undefined) && typeof successHandler === 'function')
            successHandler();
    })
        .fail(function () {
            alert("Произошла неизвестная ошибка");
        })
        .always(function () {
            SpinnerFadeOut();
            return false;
        });
}

/**
 * @param {object} keysConfig конфигурация сущностей
 * @param {string} keysConfig.RootEntityKey
 * @param {string} keysConfig.RootTargetKey
 * @param {string} keysConfig.FileEntityKey
 * @param {string} keysConfig.FileTargetKey
 * @param {string} keysConfig.FileTypeFilter
 * @param {string} keysConfig.FolderTargetKey
 * @param {object} windowConfig настройка окна
 * @param {boolean} windowConfig.ReadOnly режим только для чтения (по умолчанию false)
 * @param {boolean} windowConfig.PhotoMode режим для отображения списка фотографий с превью (по умолчанию false)
 * @param {string} windowConfig.WindowTitle отображаемое название в шторке (по умолчанию "Файлы")
 * @param {string} windowConfig.AddFileButtonTitle подпись для кнопки добавления файла (по умолчанию "Загрузить файл")
 * @param {string} windowConfig.AddFileModalTitle подпись для окна добавления файла (по умолчанию "Добавить файл")
 * @param {string} itemTitle Название целевого объекта, используется для автоматической генерации названия
 * @param {string} itemType Тип целевого объекта, используется для автоматической генерации названия, принимает значения [null, 'action', 'worktype', 'hazardSource', 'workplace']
 * @param {string} windowWidth Ширина модального окна
 */
function OpenRiskPhotoManager(fileManagerName, keyConfig, windowConfig, itemTitle = null, itemType = null, windowWidth = "70%") {

    var fileManager = RiskProf.DependencyResolvedManager.Resolved(fileManagerName);

    if (fileManager == (null || undefined)) {
        console.log('fileManager ' + fileManagerName + ' is not resolved');
        alert("Произошла неизвестная ошибка");
        return;
    }

    var guid = ModalDialogV3_show('', 'width: ' + windowWidth);

    var title = '';

    if (itemType != (null && undefined)) {
        title += "Фотографии ";
        console.log(itemType);
        switch (itemType) {
            case 'action': title += ' меры управления '; break;
            case 'workType': title += ' объекта оценки риска '; break;
            case 'hazardSource': title += ' источника опасности '; break;
            case 'workplace': title += ' рабочего места '; break;
        }

        title += '"' + itemTitle + '"';
    }

    if (windowConfig.WindowTitle == (null || undefined) || windowConfig.WindowTitle.length < 1) {
        windowConfig.WindowTitle = title;
    }


    if (fileManager.CreateFileManagerForm($('#' + guid + ' .content-modified'), keyConfig, windowConfig) == false) {
        ModalDialog_hide($('#' + guid + ' .content-modified'));
    }
}

function CopyRiskObjectById(versionId, riskObjectId, showRiskEditor, successHandler) {

    let data = {
        versionId: versionId,
        riskObjectId: riskObjectId,
    };

    $.get(_copyRiskObjectGetInfoUrl, data, function (response) {
        if (response.State != 0) {
            alert("Произошла неизвестная ошибка");
            return;
        }

        ModalDialogBoostrap_show({
            title: 'Копирование объекта оценки риска',
            message: '<div>Новое название для объекта оценки риска в печатных документах</div>\
                    <input type="text" class="form-control" id="newWtiTitle" name="newWtiTitle" />\
                    <div>Комментарий к названию</div>\
                    <input type="text" class="form-control" id="newWtiAdditionalInfo" name="newWtiAdditionalInfo" />',
            closable: false,
            draggable: false,
            buttons: [{
                label: 'Сохранить',
                cssClass: 'btn-outline-primary',
                action: function (dialog) {
                    var url = _copyRiskObjectUrl;
                    var newWtiAdditionalInfo = dialog.getModal().find('#newWtiAdditionalInfo').val();
                    var newWtiTitle = dialog.getModal().find('#newWtiTitle').val();
                    var data = {
                        'versionId': response.VersionId,
                        'riskObjectsGuid': response.RiskObjectId,
                        'workTypeItemAdditionalInfo': newWtiAdditionalInfo,
                        'workTypeItemTitle': newWtiTitle,
                    };
                    $.post(url, data, function (saveResponse) {
                        if (saveResponse.State == 0) {
                            if (successHandler != (null && undefined))
                                successHandler(saveResponse);

                            if (showRiskEditor && saveResponse.NewWorkplaces != (null || undefined) && saveResponse.NewWorkplaces.length > 0)
                                OpenWorkplaceEditorById(response.VersionId, saveResponse.NewWorkplaces[0]);
                            dialog.close();
                        }
                        else {
                            alert("Произошла неизвестная ошибка");
                            dialog.close();
                        }
                    }).fail(function () {
                        alert("Произошла неизвестная ошибка");
                        dialog.close();
                    });
                }
            }]
        },
            function (dialogRef) {
                dialogRef.getModal().find('#newWtiAdditionalInfo').val(response.AdditionalInfo);
                dialogRef.getModal().find('#newWtiTitle').val(response.WorkTypeItemTitle);
                dialogRef.getModal().css('background-color', 'rgba(0, 0, 0, 0.7)');
            },
            function (dialogRef) {
                dialogRef.getModal().css('background-color', null);
            });
        return false;
    })
};

function DeleteHazardSourceItemsWithHandler(versionId, workplaceId, hazardSourceIds, successHandler) {
    if (hazardSourceIds.length < 1) {
        alert('Не выбраны удаляемые элементы');
        return;
    }

    if (confirm("Вы уверены, что хотите удалить?")) {
        var actionUrl = _deleteHazardSourceItemsUrl + '?versionId=' + versionId;
        var data = {
            'itemGuids': hazardSourceIds,
            'targetObjectGuid': workplaceId,
        };
        $.post(actionUrl, data, function (response) {
            if (response.State == 0 && successHandler != (null && undefined))
                successHandler();
        });
    }
    return false;
};

function DeleteWorkplaceWithHandler(versionId, workplaceId, successHandler) {
    function deleteRoorWorkplace(data) {
        var url = _deleteWorkplaceUrl;
        $.get(url, data, function (response) {
            if (response.State == 0 && successHandler != (null && undefined))
                successHandler();
        });
    };

    if (confirm("Вы уверены, что хотите удалить?")) {
        var data = {
            'versionId': versionId,
            'id': workplaceId
        };
        SpinnerFadeIn();
        $.ajax({
            type: "POST",
            url: _checkWorkplaceReferencesUrl,
            data: data,
            success: function (result) {
                if (result.State == 0) {
                    if (result.ReferencesCount <= 0) {
                        deleteRoorWorkplace(data);
                        SpinnerFadeOut();
                    } else {
                        SpinnerFadeOut();
                        ModalDialogBoostrap_show({
                            title: 'Предупреждение',
                            message: function () {
                                var $message = $('<div></div>')
                                    .html('На удаляемый объект оценки риска ссылается рабочих мест: ' + result.ReferencesCount + '. Удалить объект оценки риска и все ссылки на него?');
                                return $message;
                            },
                            closable: false,
                            draggable: true,
                            buttons: [
                                {
                                    label: 'Отмена',
                                    cssClass: 'btn-outline-secondary',
                                    action: function (dialog) {
                                        dialog.close();
                                    }
                                }, {
                                    label: 'Да',
                                    cssClass: 'btn-outline-primary',
                                    action: function (dialog) {
                                        SpinnerFadeIn();
                                        deleteRoorWorkplace(data);
                                        SpinnerFadeOut();
                                        dialog.close();
                                    }
                                }
                            ]
                        });
                    }
                } else {
                    SpinnerFadeOut();
                    alert(result.Message);
                }
            },
            error: function (xhr, status, p3) {
                SpinnerFadeOut();
                alert(xhr.responseText);
            }
        });
    }
    return false;
};

function RequirementObjectEditLink(versionId, objectId, objectType, addMode) {
    var guid = null;

    var data = {
        versionId: versionId,
        objectId: objectId,
        objectType: objectType,
        addMode: addMode
    };
    SpinnerFadeIn();
    $.get(_requirementObjectLinkViewUrl, data, function (response) {
        let style = '';
        if (addMode) {
            style = 'height:90vh; max-width: 80vw;';
        }
        else {
            style = 'height:90vh; max-width: 40vw;';
        }
        guid = ModalDialogV2_show(response, null, style, null, 'height:100% !important;');
    })
        .fail(function () {
            alert("Произошла неизвестная ошибка");
        })
        .always(function () {
            SpinnerFadeOut();
            return guid;
        });
}

KbSearchWindowCommon = { }

KbSearchWindowCommon.ShowSpinner = function ($selector) {
    let spinnerHtml = '<div class="w-100 h-100 d-flex align-items-center justify-content-center"><i class="fa fa-spinner fa-pulse fa-5x fa-fw text-danger"></i></div>';
    let currentHtml = $($selector).html();

    if (currentHtml !== spinnerHtml) $($selector).html(spinnerHtml);
}

KbSearchWindowCommon.CreateWindowBodyHtml = function (buttons) {
    let styleBlock = '\
    <style>\
    .checkboxModalHolder:hover {\
    background-color: #99ff99;\
    font-weight: bold;\
    cursor: pointer;\
    }\
    .filterHolder.disabled {\
     pointer-events: none;\
     opacity: 0.4;\
    } \
    .hidden {\
     pointer-events: none;\
     opacity: 0;\
    } \
    .searchModal_TypeButton[data-targettype="category"]:after {\
     content: "Искать в категории";\
    } \
    .searchModal_TypeButton[data-targettype="all"]:after {\
     content: "Искать везде";\
    } \
    </style>\
    ';

    let buttonHtml =
        '<div style="width:{width}%" class="{margin} filterElementHolder searchModal_Filter" data-targettype="category">\
        <input type="checkbox" name="filterElementCheckbox" class="d-none" data-type="{type}" {checked}>\
        <div class="btn btn-sm btn-outline-secondary filterTitle w-100 h-100 {active}">\
            <div class="fa fa-lg {icon}"></div><div>{title}</div>\
        </div>\
    </div>';

    let buttonsHtml = '';

    buttons.forEach(buttonLine => {
        buttonsHtml += '<div class="d-flex w-100 pt-2 filterHolder">';
        let buttonWidth = 100 / buttons.length;
        buttonLine.forEach((x, i) => {
            let margin = '';

            if (buttonLine.length > 1) {
                if (i == 0) {
                    margin = 'mr-1';
                }
                else if (i == (buttonLine.length - 1)) {
                    margin = 'ml-1';
                }
                else {
                    margin = 'mx-1';
                }
            }

            let thisButtonHtml = buttonHtml.replace('{margin}', margin).replace('{width}', buttonWidth).replace('{type}', x.type).replace('{icon}', x.icon).replace('{title}', x.title);
            if (x.default == true) {
                thisButtonHtml = thisButtonHtml.replace('{checked}', 'checked').replace('{active}', 'active');
            }
            else {
                thisButtonHtml = thisButtonHtml.replace('{checked}', '').replace('{active}', '');
            }

            buttonsHtml += thisButtonHtml;
        })
        buttonsHtml += '</div>';
    });

    let windowHtml = styleBlock +
        '<div class="mb-1"><span>Введите название источника опасности</span></div>' +
        '<div class="w-100 d-flex mb-3"><div class="input-group">' +
        '<input type="text" class="form-control searchModal_Input" />' +
        '<div class="input-group-append"><button class="btn btn-outline-secondary searchModal_Clear" type="button"><span class="fa fa-times m-0"></span></button></div></div>' +
        '<button data-targettype="all" class="ml-2 btn btn-outline-secondary searchModal_TypeButton text-nowrap" type="button"></button></div>' +
        buttonsHtml +
        '<div class="searchModal_Result" style="height: 50vh; width: 100%; overflow-y: auto;"></div>';

    return windowHtml;
}

KbSearchWindowCommon.GetKbTypes = function($window) {
    let element = $window.find('input[name="filterElementCheckbox"]:checked')[0];
    if (element == (null || undefined)) return null;

    let types = $(element).attr('data-type');
    return types.split(',');
}

KbSearchWindowCommon.ToggleSearchType = function ($modal, searchInAll) {
    $modal.find('.searchModal_TypeButton').attr('data-targettype', searchInAll ? 'category' : 'all');
}

/**
 * 
 * @param {JQuery<HTMLElement>} $modal
 * @param {Function} drawSearchResultAjax
 */
KbSearchWindowCommon.Init = function ($modal, drawSearchResultAjax) {
    let timerId = null;

    $modal.off('click', '.searchModal_Clear')
    $modal.on('click', '.searchModal_Clear', function (e) {
        let $thisObject = $(this);
        $thisObject.closest('.input-group').find('.searchModal_Input').val(null);
        drawSearchResultAjax($modal);
    });

    $modal.off('click', '.filterElementHolder');
    $modal.on('click', '.filterElementHolder', function (e) {
        let $thisObject = $(this);

        $('.filterElementHolder').each((i, button) => {
            let $button = $(button);

            let $checkbox = $button.find('input[type="checkbox"]');
            $checkbox.prop('checked', button == $thisObject[0]);

            $button.find('.filterTitle').toggleClass('active', $checkbox.prop('checked'));
        });
    });

    $modal.off('click', '.searchModal_TypeButton,.searchModal_Href,.searchModal_Filter');
    $modal.on('click', '.searchModal_TypeButton,.searchModal_Href,.searchModal_Filter', function () {
        let $thisObject = $(this);
        let searchInAll = $thisObject.attr('data-targettype') == 'all';
        KbSearchWindowCommon.ToggleSearchType($modal, searchInAll);
        drawSearchResultAjax($modal);
    });

    $modal.off('keyup', '.searchModal_Input');
    $modal.on('keyup', '.searchModal_Input', function (e) {
        clearTimeout(timerId);
        timerId = null;
        let value = $(this).val();
        if (e.keyCode == 13) {
            drawSearchResultAjax($modal);
            return;
        }
        if (value.length >= 2) {
            timerId = setTimeout(function () { drawSearchResultAjax($modal); }, 2000);
        }
    });

    $modal.off('click', 'checkboxModalHolder')
    $modal.on('click', '.checkboxModalHolder', function (e) {
        let $thisObject = $(this);
        let $checkbox = $thisObject.find('input[type="checkbox"]');

        if ($checkbox[0] == e.target) return;

        let checkState = $checkbox.prop('checked');
        $checkbox.prop('checked', !checkState);
        $checkbox.trigger('change');

        return false;
    });
}

/**
 *
 * @param {JQuery<HTMLElement>} $modal
 * @param {boolean} drawSearchResultAjax
 */
KbSearchWindowCommon.FillFavoriteAndTypes = function($modal, data, singleType) {
    let types = KbSearchWindowCommon.GetKbTypes($modal);
    let type = (types == (null || undefined)) ? null : types[0];

    if ($modal.find('.searchModal_TypeButton').attr('data-targettype') == 'all') {
        if (types != (null && undefined) && types.length > 0) {
            let favoriteIndex = types.indexOf('favorite');

            if (favoriteIndex != -1) {
                types.splice(favoriteIndex, 1);
                data['isFavorite'] = true;

                if (singleType) data['type'] = type;
                else data['types'] = types;
            }
            else {
                data['isFavorite'] = false;

                if (singleType) data['type'] = type;
                else data['types'] = types;
            }
        }
        else {
            data['isFavorite'] = false;

            if (singleType) data['type'] = null;
            else data['types'] = [];
        }
    }
}

function CopyHazardSourceFromKbView(versionId, workplaceId, workTypeItemId, successHandler) {
    let countInOtherSections = 0;
    let recommended = [];
    let searchData = [];

    function drawSearchResultAjax($window) {
        let $resultHtml = $window.find('.searchModal_Result');
        let text = $window.find('.searchModal_Input').val();
        let data = {
            'versionId': versionId,
            'text': text,
            'workplaceId': workplaceId,
            'workTypeItemId': workTypeItemId,
            'isFavorite': false,
            'type': null,
        }

        KbSearchWindowCommon.FillFavoriteAndTypes($window, data, false);
        KbSearchWindowCommon.ShowSpinner($resultHtml);

        let autosearch = false;

        $.post(_hazardSourcesKbSearchUrl, data, function (response) {
            if (response.State == 0) {
                searchData = response.Data;
                recommended = response.Recommended;
                countInOtherSections = response.CountInOtherSections;

                if (autosearch && response.CountInOtherSections > 0 && response.AnyInSearchingSection != true) {
                    KbSearchWindowCommon.ToggleSearchType($window, true);
                    drawSearchResultAjax($window);
                }
                else {
                    drawSearchResult($resultHtml);
                }
            }
            else {
                alert('Произошла неизвестная ошибка');
            }
        })
        .fail(function () {
            alert('Произошла неизвестная ошибка');
        });
    }

    function drawSearchResult($selector) {

        if (searchData == (null || undefined)) searchData = [];

        if (recommended == (null || undefined)) recommended = [];

        let html = '';
        let keys = Object.keys(searchData);
        let anyHS = false;

        if (recommended.length > 0) {
            html += '<div class="d-flex p-2 border-bottom align-items-center user-select-none font-weight-bold"><span class="m-0 fa fa-riskprof-logo color-red" style="width:1.25rem"></span><div class="m-0">Ассистент рекомендует</div></div>';

            anyHS = true;

            recommended.forEach((x, i) => {
                html += '<div class="d-flex p-2 border-bottom checkboxModalHolder align-items-center user-select-none"></span><input type="checkbox" class="checkboxModal m-0 mr-2" data-id="' + x.Id + '"><div class="m-0">' + x.Title.trim() + '</div></div>';
            });
        }

        keys.forEach(key => {
            let icon = '';
            switch (key) {
                case 'Здания и сооружения': icon = 'fa-building-o'; break;
                case 'Оборудование': icon = 'fa-cogs'; break;
                case 'Территория': icon = 'fa-map-o'; break;
                case 'Трудовые действия': icon = 'fa-refresh'; break;
                case 'Поведение': icon = 'fa-users'; break;
                case 'Инструменты и приспособления': icon = 'fa-wrench'; break;
                case 'Инструменты': icon = 'fa-wrench'; break;
                case 'Сырье и материалы': icon = 'fa-cubes'; break;
                case 'Аварийные ситуации': icon = 'fa-exclamation-triangle'; break;
                default: icon = ''; break;
            }

            if (searchData[key].length > 0) {
                html += '<div class="d-flex p-2 border-bottom align-items-center user-select-none font-weight-bold"><span class="m-0 fa ' + icon + '" style="width:1.25rem"></span><div class="m-0">' + key + '</div></div>';

                anyHS = true;

                searchData[key].forEach((x, i) => {
                    html += '<div class="d-flex p-2 border-bottom checkboxModalHolder align-items-center user-select-none"></span><input type="checkbox" class="checkboxModal m-0 mr-2" data-id="' + x.Id + '"><div class="m-0">' + x.Title.trim() + '</div></div>';
                });
            }
        });

        if (anyHS == false) {
            html = '<div class="d-flex p-2 border-bottom align-items-center user-select-none font-weight-bold text-danger"><div class="m-0">Источники опасности не найдены</div></div>';
        }

        if (countInOtherSections > 0) {
            html += '<div data-targetType="all" class="d-flex p-2 border-bottom searchModal_Href align-items-center user-select-none"></span><div class="m-0"><a href="#"><b>Найдено ещё ' + countInOtherSections + ' в других категориях</b></a></div></div>';
        }

        $selector.html(html);

        $selector.scrollTop(0);
    }

    let buttons = [
        [
            {
                type: 'favorite',
                icon: 'fa-star text-warning',
                title: 'Популярные',
                default: true,
            },
            {
                type: 'tools,toolsAndDevices',
                icon: 'fa-wrench',
                title: 'Инструменты и приспособления',
            },
            {
                type: 'equipment',
                icon: 'fa-cogs',
                title: 'Оборудование',
            },
        ],
        [
            {
                type: 'materials',
                icon: 'fa-cubes',
                title: 'Сырьё и материалы',
            },
            {
                type: 'territory',
                icon: 'fa-map-o',
                title: 'Территория',
            },
            {
                type: 'buildings',
                icon: 'fa-building-o',
                title: 'Здания и сооружения',
            },
        ],
        [
            {
                type: 'workActions',
                icon: 'fa-refresh',
                title: 'Трудовые действия',
            },
            {
                type: 'behavior',
                icon: 'fa-users',
                title: 'Поведение',
            },
            {
                type: 'emergency',
                icon: 'fa-exclamation-triangle',
                title: 'Аварийные ситуации',
            },
        ],
    ];

    ModalDialogBoostrap_show({
        title: 'База знаний РискПроф - Источники опасности',
        message: KbSearchWindowCommon.CreateWindowBodyHtml(buttons),
        closable: false,
        draggable: false,
        buttons: [{
            label: 'Добавить',
            cssClass: 'btn-outline-primary float-right',
            action: function (dialog) {
                let ids = [];

                dialog.getModal().find('.checkboxModal:checked').each((i, x) => {
                    ids.push($(x).attr('data-id'));
                });

                if (ids.length < 1) {
                    dialog.close();
                    return;
                }

                let data = {
                    versionId: versionId,
                    workplaceId: workplaceId,
                    workTypeItemId: workTypeItemId,
                    selectedHazardSources: ids
                }

                $.post(_hazardSourcesKbCopyToWorkplaceUrl, data, function (response) {
                    if (response.State == 0) {
                        if (successHandler != (null && undefined) && typeof (successHandler) === "function")
                            successHandler(response);

                        dialog.close();
                    }
                    else {
                        alert((response.Message != (null && undefined)) ? response.Message : 'Произошла неизвестная ошибка');
                    }
                })
                    .fail(function () {
                        alert('Произошла неизвестная ошибка');
                    });
            }
        }]
    },
        function (dialogRef) {
            dialogRef.getModalDialog().css("max-width", "60vw");
            dialogRef.getModal().css('background-color', 'rgba(0, 0, 0, 0.7)');
            drawSearchResultAjax(dialogRef.getModal());

            KbSearchWindowCommon.Init(dialogRef.getModal(), drawSearchResultAjax);
        },
        function (dialogRef) {
            dialogRef.getModal().css('background-color', null);
        });
    return false;
};

function CopyRiskObjectsFromKbView(versionId, workplaceIds, existingRiskObjectIds,  successHandler) {
    let searchData = [];

    function drawSearchResultAjax($window) {
        let $resultHtml = $window.find('.searchModal_Result');
        let text = $window.find('.searchModal_Input').val();
        let ids = [];

        $window.find('.versionSearchFilterCheckbox:checked').each((i, x) => ids.push($(x).val()));

        let data = {
            'versionId': versionId,
            'searchString': text,
            'existingRiskObjectGuids': existingRiskObjectIds,
            'isFavorite': false,
            'type': null,
            'versionIds': ids,
        }

        KbSearchWindowCommon.FillFavoriteAndTypes($window, data, true);
        KbSearchWindowCommon.ShowSpinner($resultHtml);

        let autosearch = false;

        $.post(_riskObjectKbSearchUrl, data, function (response) {
            if (response.State == 0) {
                searchData = response.Data;
                recommended = response.Recommended;
                countInOtherSections = response.CountInOtherSections;

                if (autosearch && response.CountInOtherSections > 0 && response.AnyInSearchingSection != true) {
                    KbSearchWindowCommon.ToggleSearchType($window, true);
                    drawSearchResultAjax($window);
                }
                else {
                    drawSearchResult($resultHtml);
                }
            }
            else {
                alert('Произошла неизвестная ошибка');
            }
        })
        .fail(function () {
                alert('Произошла неизвестная ошибка');
            });
    }

    function drawSearchResult($selector) {

        if (searchData == (null || undefined)) {
            searchData = [];
        }

        let html = '';
        let keys = searchData.RiskObjectTypes;
        let anyObject = false;

        keys.forEach(key => {
            let icon = '';
            switch (key) {
                case 'Выполняемые работы': icon = 'fa-wrench'; break;
                case 'Места выполнения работ': icon = 'fa-map-marker'; break;
                case 'Нештатные ситуации': icon = 'text-warning fa-exclamation-triangle'; break;
                case 'Аварийные ситуации': icon = 'text-danger fa-exclamation-triangle'; break;
                default: icon = ''; break;
            }

            let anyObjectInGroup = false;
            let currentHtml = '';
            searchData.RiskObjects.forEach((x, i) => {
                if (x.Type != key)
                    return;

                anyObject = true;
                anyObjectInGroup = true;

                let icon = '';
                switch (x.Source) {
                    case 'this': icon = 'fa'; break;
                    case 'kb': icon = 'fa fa-database text-danger'; break;
                    case 'local': icon = 'fa fa-database text-dark'; break;
                }
                currentHtml += '<div class="d-flex p-2 border-bottom checkboxModalHolder"><div class="w-50 w-50 d-flex align-items-center user-select-none"><span style="width: 1.25em" class="' + icon + '"></span><input type="checkbox" class="riskObjectElement checkboxModal m-0 mr-2" data-source="' + x.Source + '" data-templateId="' + x.TemplateId + '" data-id="' + x.Id + '"><div class="m-0">' + x.Title.trim() + '</div></div><div class="w-50">' + x.TemplateTitle + '</div></div>';
            });

            if (anyObjectInGroup) {
                html += '<div class="d-flex p-2 border-bottom align-items-center user-select-none font-weight-bold"><span class="m-0 fa ' + icon + '" style="width:1.25rem"></span><div class="m-0">' + key + '</div></div>';
                html += currentHtml;
            }
        });


        if (anyObject == false) {
            html = '<div class="d-flex p-2 border-bottom align-items-center user-select-none font-weight-bold text-danger"><div class="m-0">Объекты оценки риска не найдены</div></div>';
        }

        {
            let anySelected = false;

            let dropdownLi = '';

            let liMask = '<li><a href="#" class="list-group-item list-group-item-action checkboxModalHolder py-2"><div>{icon}<input type="checkbox" value="{value}" class="checkboxModal versionSearchFilterCheckbox mr-2" style="width: unset !important;" {isChecked}>{title}</div></a></li>\n';

            function getLi(checked, title, value, icon) {
                return liMask.replaceAll('{isChecked}', checked ? 'checked' : '').replaceAll('{title}', title).replaceAll('{value}', value).replaceAll('{icon}', icon);
            }
            searchData?.KbVersionList.forEach(x => {
                dropdownLi += getLi(x.Selected, x.Text, x.Value, '<span class="fa fa-database color-red" style="width:1.25rem;"></span>');
                if (x.Selected) anySelected = true;
            });

            if (searchData?.LocalVersionList.length > 0) dropdownLi += '<li class="dropdown-divider my-0"></li>\n';

            searchData?.LocalVersionList.forEach(x => {
                dropdownLi += getLi(x.Selected, x.Text, x.Value, '<span class="fa fa-database color-black" style="width:1.25rem;"></span>');
                if (x.Selected) anySelected = true;
            });

            if (searchData?.ThisVersionList.length > 0) dropdownLi += '<li class="dropdown-divider my-0"></li>\n';

            searchData?.ThisVersionList.forEach(x => {
                dropdownLi += getLi(x.Selected, x.Text, x.Value, '<span class="fa" style="width:1.25rem;"></span>');
                if (x.Selected) anySelected = true;
            });


            let dropdownUl = '<ul class="list-group list-group-flush ">' + dropdownLi + '</ul>\n';

            let dropdownMenu = '<div class="our-dropdown__items dropdown-menu dropdown-menu-md p-0" aria-labelledby="dropdownVersionFilter">' + dropdownUl + '</div>\n';

            let button = '<span class="text-center ' + (anySelected ? 'color-red' : '') +' menu-dropdown__a" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" id="dropdownVersionFilter" style="cursor:pointer;"><span>Проект</span><span class="ml-2 fa fa-filter"></span></span>\n';

            let dropDown = '<div class="dropdown our-dropdown dropdownInList" style="position:relative;">' + button + dropdownMenu + '</div>';

            html = '<div class="d-flex p-2 border-bottom align-items-center user-select-none bg-light" style="position:sticky; top: 0px; box-shadow: 0px 4px 4px 0px #00000038;"><div class="w-50">Название</div><div class="w-50">' + dropDown + '</div></div>' + html;
        }

        if (countInOtherSections > 0) {
            html += '<div data-targetType="all" class="d-flex p-2 border-bottom searchModal_Href align-items-center user-select-none"></span><div class="m-0"><a href="#"><b>Найдено ещё ' + countInOtherSections + ' в других категориях</b></a></div></div>';
        }

        $selector.html(html);
        $selector.scrollTop(0);
    }

    let buttons = [
        [
            {
                type: 'favorite',
                icon: 'fa-star text-warning',
                title: 'Популярные',
                default: true,
            },
            {
                type: 'work',
                icon: 'fa-wrench',
                title: 'Работы',
            },
            {
                type: 'place',
                icon: 'fa-map-marker',
                title: 'Места',
            },
            {
                type: 'extraordinary',
                icon: 'text-warning fa-exclamation-triangle',
                title: 'Ситуации',
            },
            {
                type: 'emergency',
                icon: 'text-danger fa-exclamation-triangle',
                title: 'Аварии',
            },
        ],
    ];

    ModalDialogBoostrap_show({
        title: 'База знаний РискПроф - Работы, места, ситуации',
        message: KbSearchWindowCommon.CreateWindowBodyHtml(buttons),
        closable: false,
        draggable: false,
        buttons: [{
            label: 'Добавить',
            cssClass: 'btn-outline-primary float-right',
            action: function (dialog) {
                let ids = [];

                dialog.getModal().find('.checkboxModal:checked').each((i, x) => {
                    ids.push($(x).attr('data-id'));
                });

                if (ids.length < 1) {
                    dialog.close();
                    return;
                }

                let data = {
                    versionId: versionId,
                    workplaceIds: workplaceIds,
                    addRiskObjects: [],
                    removeRiskObjects: [],
                    templateKbGuidsDictionary: {},
                    templateLocalGuidsDictionary: {},
                };

                dialog.getModal().find('.checkboxModal:checked').each((i, x) => {
                    let id = $(x).attr('data-id');
                    let source = $(x).attr('data-source');
                    let templateId = $(x).attr('data-templateid');

                    switch (source) {
                        case 'kb':
                            if (data.templateKbGuidsDictionary[templateId] == (null || undefined))
                                data.templateKbGuidsDictionary[templateId] = [];

                            if (data.templateKbGuidsDictionary[templateId].indexOf(id) == -1)
                                data.templateKbGuidsDictionary[templateId].push(id);
                            break;
                        case 'local':
                            if (data.templateLocalGuidsDictionary[templateId] == (null || undefined))
                                data.templateLocalGuidsDictionary[templateId] = [];

                            if (data.templateLocalGuidsDictionary[templateId].indexOf(id) == -1)
                                data.templateLocalGuidsDictionary[templateId].push(id);
                            break;
                        case 'this':
                            data.addRiskObjects.push(id);
                            break;
                    }
                });

                let massEditUrl = (data.workplaceIds == (null || undefined) || data.workplaceIds.length < 1) ? _riskObjectKbCopyFromTemplateUrl : _riskObjectKbCopyToWorkplacesUrl;

                $.ajax({
                    type: "POST",
                    url: massEditUrl,
                    data: data,
                    success: function (response) {
                        if (response.State == 0) {
                            if (successHandler != (null && undefined) && typeof (successHandler) === 'function') {
                                successHandler(response);
                            }
                            dialog.close();
                            return;
                        }
                        else {
                            alert('Произошла неизвестная ошибка');
                        }
                    },
                    error: function () {
                        alert('Произошла неизвестная ошибка');
                    }
                });
            }
        }]
    },
        function (dialogRef) {
            dialogRef.getModalDialog().css("max-width", "60vw");
            dialogRef.getModal().css('background-color', 'rgba(0, 0, 0, 0.7)');
            drawSearchResultAjax(dialogRef.getModal());

            KbSearchWindowCommon.Init(dialogRef.getModal(), drawSearchResultAjax);

            dialogRef.getModal().off('show.bs.dropdown', '.dropdown.dropdownInList');
            dialogRef.getModal().on('show.bs.dropdown', '.dropdown.dropdownInList', function () {
                let $_dropdown = dialogRef.getModal().find('.dropdown.dropdownInList .dropdown-menu');
                $_dropdown.toggleClass('dropdownMenuInModal', true);
                dialogRef.getModal().append($_dropdown.css({
                    position: 'absolute',
                    left: $_dropdown.offset().left,
                    top: $_dropdown.offset().top,
                }).detach());
            });

            dialogRef.getModal().off('hidden.bs.dropdown');
            dialogRef.getModal().on('hidden.bs.dropdown', function (e) {
                console.log(e);
                let $_dropdown = dialogRef.getModal().find('.dropdown.dropdownInList');
                let $_dropdownMenu = dialogRef.getModal().find('.dropdown-menu.dropdownMenuInModal');
                $_dropdownMenu.toggleClass('dropdownMenuInModal', false);
                console.log($_dropdownMenu);
                $_dropdown.append($_dropdownMenu.css({
                    position: false,
                    left: false,
                    top: false
                }).detach());
            });

            dialogRef.getModal().off('change', '.versionSearchFilterCheckbox');
            dialogRef.getModal().on('change', '.versionSearchFilterCheckbox', function () {

                let hiddenTemplates = [];

                let anyChecked = $('.versionSearchFilterCheckbox:checked').length > 0;

                if (anyChecked) {
                    $('.versionSearchFilterCheckbox').each((i, x) => { if ($(x).prop('checked') == false) hiddenTemplates.push($(x).val()); });
                }

                $('#dropdownVersionFilter').toggleClass('color-red', anyChecked);

                $('.riskObjectElement').each((i, x) => {
                    let templateId = $(x).attr('data-templateid');
                    let hide = hiddenTemplates.indexOf(templateId) != -1;

                    $(x).closest('.checkboxModalHolder').toggleClass('d-none', hide).toggleClass('d-flex', !hide);
                });

            });
        },
        function (dialogRef) {
            dialogRef.getModal().css('background-color', null);
        });
    return false;
};

function WorkEnvironmentView(versionId, targetObjectId) {

    var data = {
        'versionId': versionId,
        'targetObjectId': targetObjectId,
    };
    SpinnerFadeIn();
    $.get(_workEnvironmentViewUrl, data, function (response) {
        ModalDialogV3_show(response, "width: calc(100% - 32px);");
        return;
    }).fail(function () { alert("error"); })
        .always(function () {
            SpinnerFadeOut();
        });
}

function ReportSettingsModalDialog(versionId) {
    let windowAjaxData = {
        'versionId': versionId
    };
    SpinnerFadeIn();
    $.get(_reportSettingsViewUrl, windowAjaxData, function (response) {
        if (response.Message != null) {
            alert(response.Message);
        }
        else {
            ModalDialogBoostrap_show({
                title: 'Настройки отчетов',
                message: $('<div></div>').html(response),
                closable: true,
                draggable: false,
                onshown: function (dialogRef) {
                    $(".questionSettings").popover();
                    $(".questionFileTemplate").popover();

                    setMarkerInputHandlers(dialogRef.getModal(), 'FileNameTemplate', 'AddReplaceMarker');
                    setMarkerInputHandlers(dialogRef.getModal(), 'AddressNameTemplate', 'AddReplaceMarker_Address');

                    dialogRef.getModal().on('keydown', '#ReportTableFontSize', function (e) {
                        if (e.key.length == 1 && e.key.match(/[^0-9]/)) {
                            return false;
                        }
                    });

                    dialogRef.getModal().on('click', '.RemoveReplaceMarker', function () {
                        var marker = $(this).attr('data-marker');
                        var result = $(lastFocusField).val().replace(marker, '');
                        $(lastFocusField).val(result);
                    });

                    dialogRef.getModal().on('click', '#UpdateReportForms', function () {
                        SpinnerFadeIn();
                        $.ajax({
                            type: "POST",
                            url: _reportUpdateUrl,
                            data: {
                                'versionId': versionId
                            },
                            success: function (result) {
                                if (result.State == 0) {
                                    $.notify({
                                        icon: 'fa fa-check',
                                        message: "<strong>Список форм обновлен</strong>"
                                    }, notifySettingsSuccess);

                                    $.get(_reportSettingsViewUrl, windowAjaxData, function (newWindowResponse) {
                                        if (newWindowResponse.Message != null) {
                                            alert(newWindowResponse.Message);
                                        }
                                        else {
                                            let _html = newWindowResponse.replaceAll('\r\n', '').replaceAll('\n', '');
                                            dialogRef.setMessage(_html);
                                        }
                                    });
                                }
                                else {
                                    alert(result.Message);
                                }
                            },
                            error: function (xhr, status, p3) {
                                alert(xhr.responseText);
                            }
                        }).always(function () {
                            SpinnerFadeOut();
                        });
                    });
                },
                buttons: [{
                    label: 'Отмена',
                    cssClass: 'btn-outline-secondary',
                    action: function (dialog) {
                        dialog.close();
                    }
                }, {
                    label: 'Сохранить',
                    cssClass: 'btn-outline-primary',
                    action: function (dialog) {
                        var formArray = $('#settingsForm').serializeArray();
                        var formObject = {};
                        for (var i = 0; i < formArray.length; i++) {
                            formObject[formArray[i]['name']] = formArray[i]['value'];
                        }
                        var formUrl = $('#settingsForm').attr('url');
                        formObject.ReportForms = [];
                        var reportFormsElements = $('.report-form-checkboxes');
                        for (var i = 0; i < reportFormsElements.length; i++) {
                            var reportFormElement = $(reportFormsElements[i]);
                            var reportFormData = {
                                No: reportFormElement.attr('data-no'),
                                FileNameTemplate: $('input[data-name="FileNameTemplate"]', reportFormElement)[0].value,
                                IsWorkingReport: $('input[data-name="IsWorkingReport"]', reportFormElement)[0].checked,
                                IsFinalReport: $('input[data-name="IsFinalReport"]', reportFormElement)[0].checked
                            }
                            formObject.ReportForms.push(reportFormData);
                        }
                        SpinnerFadeIn();
                        $.post(formUrl, formObject, function (response) {
                            if (response.State == 0) {
                                $.notify({
                                    icon: 'fa fa-check',
                                    message: "<strong>Настройки сохранены</strong>"
                                }, notifySettingsSuccess);
                                dialog.close();
                            } else { alert(response.Message); }
                        })
                            .fail(function (xhr, status, p3) { alert(xhr.responseText); })
                            .always(function () {
                                SpinnerFadeOut();
                            });
                    }
                }]
            },
                function (dialogRef) {
                    dialogRef.getModalDialog().addClass('modal-xl').css("max-height", "70vh");
                });
        }
    }).always(function () {
        SpinnerFadeOut();
    });

    function setMarkerInputHandlers(modalObject, markerInputName, markerButtonName) {
        modalObject.on('click', '[data-name="' + markerInputName + '"]', function () {
            var thisObject = this;
            $('[data-name="' + markerInputName + '"]').each((i, x) => {
                x.removeAttribute("cursor-position");
            })
            setTimeout(function () {
                thisObject.setAttribute("cursor-position", thisObject.selectionStart);
            }, 20);
        });

        modalObject.on('keypress', '[data-name="' + markerInputName + '"]', function () {
            var thisObject = this;
            thisObject.setAttribute("cursor-position", thisObject.selectionStart);
        });

        modalObject.on('click', '.' + markerButtonName, function () {
            var marker = $(this).attr('data-marker');
            var input = document.querySelector('[data-name="' + markerInputName + '"][cursor-position]');
            var position = input.getAttribute('cursor-position');
            var value = input.value;
            input.value = value.substring(0, position) + marker + value.substring(position);
            input.setAttribute("cursor-position", Number(position) + marker.length);
        });
    }
}