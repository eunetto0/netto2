﻿/**
 * @typedef {Object} Paths
 * @property {string} InnerPath
 * @property {string} UserPath
 */

if (RiskProf == (null || undefined))
    RiskProf = {};

if (RiskProf.Risk == (null || undefined))
    RiskProf.Risk = {};

RiskProf.Risk.ProjectPhotoPaths = function () {
    this._actionInnerPath = 'version_{versionId}/Photos/Actions/{workplaceId}/{hazardId}/{actionId}';
    this._actionUserPath = 'Корневая папка версии {versionId}/Фотографии/Меры управления/{workplaceTitle}/{hazardTitle}/{actionTitle}';

    this._hazardSourceInnerPath = 'version_{versionId}/Photos/HazardSources/{workplaceId}/{hazardsourceId}';
    this._hazardSourceUserPath = 'Корневая папка версии {versionId}/Фотографии/Источники опасности/{workplaceTitle}/{hazardsourceTitle}';

    this._workTypeInnerPath = 'version_{versionId}/Photos/WorkTypes/{workplaceId}/{worktypeId}';
    this._workTypeUserPath = 'Корневая папка версии {versionId}/Фотографии/Объекты оценки риска/{workplaceTitle}/{worktypeTitle}';

    this._workplaceInnerPath = 'version_{versionId}/Photos/Workplaces/{workplaceId}';
    this._workplaceUserPath = 'Корневая папка версии {versionId}/Фотографии/Рабочие места/{workplaceTitle}';
}

/**
 * @returns {Paths} inner and user Paths
 */
RiskProf.Risk.ProjectPhotoPaths.prototype.GetActionItemPaths = function (versionId, workplaceId, hazardId, actionId, workplaceTitle, hazardTitle, actionTitle) {
    let thisObject = this;
    let result = {
        InnerPath: thisObject._actionInnerPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{hazardId}', hazardId)
            .replaceAll('{actionId}', actionId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{hazardTitle}', hazardTitle)
            .replaceAll('{actionTitle}', actionTitle),

        UserPath: thisObject._actionUserPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{hazardId}', hazardId)
            .replaceAll('{actionId}', actionId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{hazardTitle}', hazardTitle)
            .replaceAll('{actionTitle}', actionTitle)
    };

    return result;
}

/**
 * @returns {Paths} inner and user Paths
 */
RiskProf.Risk.ProjectPhotoPaths.prototype.GetHazardSourceItemPaths = function (versionId, workplaceId, hazardsourceId, workplaceTitle, hazardsourceTitle) {
    let thisObject = this;
    let result = {
        InnerPath: thisObject._hazardSourceInnerPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{hazardsourceId}', hazardsourceId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{hazardsourceTitle}', hazardsourceTitle),

        UserPath: thisObject._hazardSourceUserPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{hazardsourceId}', hazardsourceId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{hazardsourceTitle}', hazardsourceTitle)
    };

    return result;
}

/**
 * @returns {Paths} inner and user Paths
 */
RiskProf.Risk.ProjectPhotoPaths.prototype.GetWorktypeItemPaths = function (versionId, workplaceId, worktypeId, workplaceTitle, worktypeTitle) {
    let thisObject = this;
    let result = {
        InnerPath: thisObject._workTypeInnerPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{worktypeId}', worktypeId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{worktypeTitle}', worktypeTitle),

        UserPath: thisObject._workTypeUserPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{worktypeId}', worktypeId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
            .replaceAll('{worktypeTitle}', worktypeTitle)
    };

    return result;
}

/**
 * @returns {Paths} inner and user Paths
 */
RiskProf.Risk.ProjectPhotoPaths.prototype.GetWorkplacePaths = function (versionId, workplaceId, workplaceTitle) {
    let thisObject = this;
    let result = {
        InnerPath: thisObject._workplaceInnerPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{workplaceTitle}', workplaceTitle),

        UserPath: thisObject._workplaceUserPath
            .replaceAll('{versionId}', versionId)
            .replaceAll('{workplaceId}', workplaceId)
            .replaceAll('{workplaceTitle}', workplaceTitle)
    };

    return result;
}

RiskProf.Risk.ProjectPhotoPaths.Instance = new RiskProf.Risk.ProjectPhotoPaths();