﻿/**
 * @@return {boolean}
 * */
function GetShowChildNodesCookieValue() {
    let valueString = getCookie('Show_child_nodes');
    let valueBool = true;
    if (valueString == 'false') {
        valueBool = false;
    }
    else if (valueString == (null || undefined) || valueString.length < 1) {
        setCookie('Show_child_nodes', 'true', 30);
    }
    return valueBool;
}
/**
 *
 * @@param {boolean} value
 * @@return {void}
 */
function SetShowChildNodesCookieValue(value) {
    let valueString = 'true';

    if (typeof (value) === 'boolean' && value == false) {
        valueString = 'false';
    }
    setCookie('Show_child_nodes', valueString, 30);
}
/**
 * @@return {boolean}
 * */
function GetShowInnerFoldersCookieValue() {
    let valueString = getCookie('Show_inner_folders');
    let valueBool = true;
    if (valueString == 'false') {
        valueBool = false;
    }
    else if (valueString == (null || undefined) || valueString.length < 1) {
        setCookie('Show_inner_folders', 'true', 30);
    }
    return valueBool;
}
/**
 *
 * @@param {boolean} value
 * @@return {void}
 */
function SetShowInnerFoldersCookieValue(value) {
    let valueString = 'true';

    if (typeof (value) === 'boolean' && value == false) {
        valueString = 'false';
    }
    setCookie('Show_inner_folders', valueString, 30);
}